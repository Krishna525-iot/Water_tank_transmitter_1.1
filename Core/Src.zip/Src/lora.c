/* ====================================================================
 * lora.c  —  TRANSMITTER LoRa driver (state-machine version)
 *
 * KEY BEHAVIOURS:
 *
 * 1. Powers up in DISCONNECTED.  Will NOT transmit @TL data packets
 *    until handshake is confirmed.  Sends @HI every TX_HELLO_RETRY_MS
 *    until @ACK arrives.
 *
 * 2. Once CONNECTED:
 *      • Caller passes tank_level/well_dry each cycle.
 *      • If TX_DATA_INTERVAL_MS elapsed → send @TL.
 *      • Else if TX_KEEPALIVE_INTERVAL_MS elapsed without traffic →
 *        send @PI (ping) — keeps RX side from going STALE.
 *
 * 3. Each transmit waits up to LORA_ACK_WAIT_MS for ACK.  After
 *    TX_DATA_RETRY_MAX failed retries inside ONE call, the cycle is
 *    counted as a failure.  After TX_NOACK_DISCONNECT_THRESH consecutive
 *    cycle-failures the state drops to DISCONNECTED → next call will
 *    re-handshake before any more data is attempted.
 *
 * 4. Handles @SY (sync request from RX): forces an immediate HELLO
 *    so the RX can re-pair without losing any data window.
 *
 * 5. Long-range radio config: SF10 / BW125 / +20 dBm PA_BOOST / 12 sym
 *    preamble.  See lora_protocol.h to flip to SF12 if you need more.
 * ==================================================================== */

#include "lora.h"
#include "lora_parser.h"
#include "device_id.h"
#include "stm32f1xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

extern SPI_HandleTypeDef  hspi1;
extern UART_HandleTypeDef huart1;
extern void UART_PrintLn(const char *s);

/* txPacket is defined in main.c — extern reference only.
 * Do NOT define it here or the linker will report "multiple definition".*/
extern volatile char txPacket[TX_PACKET_SIZE];

/* ── Debug: last transmitted packet (for Live Expressions) ──────────── */
volatile char g_lastTxPacket[MAX_PACKET_LEN] = {0};

/* ── Public globals ─────────────────────────────────────────────────── */
uint8_t  loraMode        = LORA_MODE_TRANSMITTER;
uint8_t  g_txConnected   = 0;
uint8_t  g_txDebugMode   = 0;
uint32_t g_lora_tx_ok    = 0;
uint32_t g_lora_tx_retry = 0;
uint32_t g_lora_tx_fail  = 0;

/* ── Private state ──────────────────────────────────────────────────── */
static LoRa_ConnState_t s_state               = LORA_STATE_DISCONNECTED;
static uint32_t         s_txSeq               = 0;
static uint32_t         s_lastDataTxTick      = 0;
static uint32_t         s_lastAnyTxTick       = 0;
static uint32_t         s_lastHelloTick       = 0;
static uint8_t          s_consecCycleFails    = 0;
static uint8_t          s_rxBuf[LORA_BUF_SIZE];

#define NSS_LOW()   HAL_GPIO_WritePin(LORA_NSS_PORT, LORA_NSS_PIN, GPIO_PIN_RESET)
#define NSS_HIGH()  HAL_GPIO_WritePin(LORA_NSS_PORT, LORA_NSS_PIN, GPIO_PIN_SET)

/* ── SPI primitives ─────────────────────────────────────────────────── */

void LoRa_WriteReg(uint8_t addr, uint8_t data)
{
    uint8_t buf[2] = { (uint8_t)(addr | 0x80), data };
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, buf, 2, HAL_MAX_DELAY);
    NSS_HIGH();
}

uint8_t LoRa_ReadReg(uint8_t addr)
{
    uint8_t tx = (uint8_t)(addr & 0x7F), rx = 0;
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &tx, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, &rx, 1, HAL_MAX_DELAY);
    NSS_HIGH();
    return rx;
}

static void LoRa_WriteBuffer(uint8_t addr, const uint8_t *data, uint8_t size)
{
    uint8_t a = (uint8_t)(addr | 0x80);
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &a, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, (uint8_t *)data, size, HAL_MAX_DELAY);
    NSS_HIGH();
}

static void LoRa_ReadBuffer(uint8_t addr, uint8_t *data, uint8_t size)
{
    uint8_t a = (uint8_t)(addr & 0x7F);
    NSS_LOW();
    HAL_SPI_Transmit(&hspi1, &a, 1, HAL_MAX_DELAY);
    HAL_SPI_Receive(&hspi1, data, size, HAL_MAX_DELAY);
    NSS_HIGH();
}

/* ── Radio mode helpers ─────────────────────────────────────────────── */

static void LoRa_Reset(void)
{
    HAL_GPIO_WritePin(LORA_RESET_PORT, LORA_RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(5);
    HAL_GPIO_WritePin(LORA_RESET_PORT, LORA_RESET_PIN, GPIO_PIN_SET);
    HAL_Delay(10);
}

static inline void LoRa_Standby (void) { LoRa_WriteReg(0x01, 0x81); }
static inline void LoRa_RxSingle(void)
{
    LoRa_WriteReg(0x12, 0xFF);
    LoRa_WriteReg(0x01, 0x86);
}

/* ── Low-level transmit (one packet, no retry) ──────────────────────── */
static bool LoRa_DoTransmit(const char *pkt, uint8_t len)
{
    if (pkt == NULL || len == 0 || len >= LORA_BUF_SIZE)
        return false;

    /* Copy to debug buffer so it's visible in Live Expressions         */
    if (len < MAX_PACKET_LEN)
    {
        memcpy((void *)g_lastTxPacket, pkt, len);
        g_lastTxPacket[len] = '\0';
    }

    LoRa_Standby();
    HAL_Delay(LORA_TX_TO_RX_GAP_MS);

    LoRa_WriteReg(0x0D, 0x00);                            /* FIFO TX base */
    LoRa_WriteBuffer(0x00, (const uint8_t *)pkt, len);
    LoRa_WriteReg(0x22, len);                             /* PayloadLen   */
    LoRa_WriteReg(0x12, 0xFF);                            /* clear IRQs   */
    LoRa_WriteReg(0x01, 0x83);                            /* TX mode      */

    uint32_t t0 = HAL_GetTick();
    while ((LoRa_ReadReg(0x12) & 0x08) == 0)
    {
        if ((HAL_GetTick() - t0) > LORA_TX_TIMEOUT_MS)
        {
            LoRa_WriteReg(0x12, 0xFF);
            LoRa_Standby();
            return false;
        }
    }

    LoRa_WriteReg(0x12, 0x08);                            /* clear TxDone */
    LoRa_Standby();
    s_lastAnyTxTick = HAL_GetTick();
    return true;
}

/* ── Low-level receive — single shot, with timeout ──────────────────── */
static uint8_t LoRa_DoReceive(uint32_t timeout_ms)
{
    /* Brief gap before flipping to RX — gives PA droop time to settle  */
    HAL_Delay(LORA_RX_TO_TX_GAP_MS);
    LoRa_RxSingle();

    uint32_t t0 = HAL_GetTick();
    while ((HAL_GetTick() - t0) < timeout_ms)
    {
        if (HAL_GPIO_ReadPin(LORA_DIO0_PORT, LORA_DIO0_PIN) == GPIO_PIN_RESET)
            continue;

        uint8_t irq = LoRa_ReadReg(0x12);
        LoRa_WriteReg(0x12, 0xFF);

        if (irq & 0x20) { LoRa_Standby(); return 0; }        /* CRC err */
        if ((irq & 0x40) == 0) continue;                      /* not RxDone */

        uint8_t len = LoRa_ReadReg(0x13);
        if (len == 0 || len >= (LORA_BUF_SIZE - 1))
        {
            LoRa_Standby();
            return 0;
        }

        LoRa_WriteReg(0x0D, LoRa_ReadReg(0x10));
        LoRa_ReadBuffer(0x00, s_rxBuf, len);
        s_rxBuf[len] = '\0';
        LoRa_Standby();
        return len;
    }

    LoRa_WriteReg(0x12, 0xFF);
    LoRa_Standby();
    return 0;
}

/* ── State helpers ──────────────────────────────────────────────────── */
static void set_state(LoRa_ConnState_t new_state)
{
    if (s_state == new_state) return;

    s_state = new_state;
    g_txConnected = (new_state == LORA_STATE_CONNECTED) ? 1 : 0;

    char dbg[80];
    snprintf(dbg, sizeof(dbg), "[LORA TX] STATE -> %s", LoRa_GetStateString());
    UART_PrintLn(dbg);
}

const char *LoRa_GetStateString(void)
{
    switch (s_state)
    {
        case LORA_STATE_DISCONNECTED: return "DISCONNECTED";
        case LORA_STATE_HANDSHAKING : return "HANDSHAKING";
        case LORA_STATE_CONNECTED   : return "CONNECTED";
        case LORA_STATE_STALE       : return "STALE";
        default                     : return "?";
    }
}

LoRa_ConnState_t LoRa_GetState(void)     { return s_state;  }
uint32_t         LoRa_GetTxSequence(void){ return s_txSeq;  }

/* ── Send one packet and wait for valid response ────────────────────── *
 *
 * Returns:
 *   true  : received any valid response packet (caller checks .type)
 *   false : no response within timeout / parse failed
 *
 * On success, *out_resp holds the parsed reply.
 * ──────────────────────────────────────────────────────────────────── */
static bool send_and_wait_response(const char *pkt, uint8_t len,
                                   uint32_t wait_ms,
                                   ParsedPacket_t *out_resp)
{
    if (!LoRa_DoTransmit(pkt, len))
        return false;

    uint8_t rlen = LoRa_DoReceive(wait_ms);
    if (rlen == 0)
        return false;

    return LoRa_ParsePacket((const char *)s_rxBuf, out_resp);
}

/* ── Handshake (one attempt) ────────────────────────────────────────── */
static bool do_handshake_once(void)
{
    char hello[32];
    int  n = LoRa_BuildHello(hello, sizeof(hello), DeviceID_GetOwn());
    if (n <= 0) return false;

    ParsedPacket_t resp;
    if (!send_and_wait_response(hello, (uint8_t)n,
                                LORA_HELLO_ACK_WAIT_MS, &resp))
    {
        return false;
    }

    /* Accept ACK matching our DID, or any HELLO from RX (some RXs
     * announce themselves), or PONG echo.                           */
    if (resp.type == PKT_TYPE_ACK && resp.did == DeviceID_GetOwn())
    {
        return true;
    }

    if (resp.type == PKT_TYPE_REJECT)
    {
        UART_PrintLn("[LORA TX] HELLO rejected — RX needs pairing mode");
        return false;
    }

    return false;
}

/* ── Public API: trigger handshake on demand ────────────────────────── */
bool LoRa_TriggerHandshake(void)
{
    UART_PrintLn("[LORA TX] Manual HELLO requested");
    set_state(LORA_STATE_HANDSHAKING);
    s_lastHelloTick = HAL_GetTick();

    if (do_handshake_once())
    {
        UART_PrintLn("[LORA TX] *** HANDSHAKE OK — CONNECTED ***");
        set_state(LORA_STATE_CONNECTED);
        s_consecCycleFails = 0;
        return true;
    }

    UART_PrintLn("[LORA TX] HELLO no response — back to DISCONNECTED");
    set_state(LORA_STATE_DISCONNECTED);
    return false;
}

/* Compat wrapper for existing main.c                                  */
void LoRa_ManualHello(void) { (void)LoRa_TriggerHandshake(); }

/* ── Send BYE on shutdown ───────────────────────────────────────────── */
void LoRa_SendBye(void)
{
    char bye[24];
    int  n = LoRa_BuildBye(bye, sizeof(bye), DeviceID_GetOwn());
    if (n > 0)
        (void)LoRa_DoTransmit(bye, (uint8_t)n);
}

/* ── Compat shim for adc.c which builds into txPacket ───────────────── */
void LoRa_BuildDataPacket(char *out, uint16_t out_size,
                          uint8_t tank_level, uint8_t well_dry)
{
    (void)LoRa_BuildData(out, (int)out_size,
                         DeviceID_GetOwn(), s_txSeq,
                         tank_level, well_dry);
}

/* ── Send DATA with retries, return outcome ─────────────────────────── */
static LoRa_TxResult send_data_with_retries(uint8_t level, uint8_t wd)
{
    uint32_t seq_for_this_attempt = s_txSeq + 1;  /* don't pre-bump   */

    for (uint8_t attempt = 0; attempt < TX_DATA_RETRY_MAX; attempt++)
    {
        char pkt[MAX_PACKET_LEN];
        int  n = LoRa_BuildData(pkt, sizeof(pkt),
                                DeviceID_GetOwn(),
                                seq_for_this_attempt,
                                level, wd);
        if (n <= 0) { g_lora_tx_fail++; return LORA_TX_FAIL; }

        ParsedPacket_t resp;
        bool got = send_and_wait_response(pkt, (uint8_t)n,
                                          LORA_ACK_WAIT_MS, &resp);

        if (got && resp.type == PKT_TYPE_ACK && resp.did == DeviceID_GetOwn())
        {
            g_lora_tx_ok++;
            s_txSeq = seq_for_this_attempt;
            s_lastDataTxTick = HAL_GetTick();
            return LORA_TX_OK;
        }

        if (got && resp.type == PKT_TYPE_REJECT)
        {
            /* RX dropped pairing — go back to handshake               */
            g_lora_tx_fail++;
            return LORA_TX_FAIL;
        }

        if (got && resp.type == PKT_TYPE_SYNC_REQ)
        {
            /* RX explicitly asking us to re-handshake                 */
            UART_PrintLn("[LORA TX] RX sent SYNC_REQ — will re-handshake");
            g_lora_tx_retry++;
            return LORA_TX_FAIL;
        }

        g_lora_tx_retry++;
    }

    g_lora_tx_fail++;
    return LORA_TX_RETRY;
}

/* ── Send PING, expect PONG ─────────────────────────────────────────── */
static bool send_ping(void)
{
    char pkt[MAX_PACKET_LEN];
    int  n = LoRa_BuildPing(pkt, sizeof(pkt),
                            DeviceID_GetOwn(), s_txSeq);
    if (n <= 0) return false;

    ParsedPacket_t resp;
    if (!send_and_wait_response(pkt, (uint8_t)n, LORA_ACK_WAIT_MS, &resp))
        return false;

    /* Accept either PONG or plain ACK as proof of life */
    if (resp.type == PKT_TYPE_PONG && resp.did == DeviceID_GetOwn())
        return true;
    if (resp.type == PKT_TYPE_ACK  && resp.did == DeviceID_GetOwn())
        return true;
    return false;
}

/* ── Init ───────────────────────────────────────────────────────────── */
void LoRa_Init(void)
{
    DeviceID_Init();
    /* PairedDev_Init() intentionally omitted on TX — no EEPROM,
     * no paired-device list.  TX broadcasts to any paired RX.        */
    LoRa_Reset();

    LoRa_WriteReg(0x01, 0x80);          /* sleep, LoRa mode */
    HAL_Delay(10);

    /* Frequency: 433 MHz */
    uint64_t frf = ((uint64_t)433000000ULL << 19) / 32000000ULL;
    LoRa_WriteReg(0x06, (uint8_t)(frf >> 16));
    LoRa_WriteReg(0x07, (uint8_t)(frf >> 8));
    LoRa_WriteReg(0x08, (uint8_t)(frf));

    /* Preamble length */
    LoRa_WriteReg(0x20, LORA_PREAMBLE_MSB);
    LoRa_WriteReg(0x21, LORA_PREAMBLE_LSB);

    /* PA: +20 dBm PA_BOOST                                            */
    LoRa_WriteReg(0x09, LORA_REG_PA_CONFIG);
    LoRa_WriteReg(0x0B, LORA_REG_OCP);
    LoRa_WriteReg(0x4D, LORA_REG_PA_DAC);

    /* Modem cfg + sync word */
    LoRa_WriteReg(0x1D, LORA_REG_MODEM_CFG1);
    LoRa_WriteReg(0x1E, LORA_REG_MODEM_CFG2);
    LoRa_WriteReg(0x26, LORA_REG_DETECT_OPT);
    LoRa_WriteReg(0x39, LORA_SYNC_WORD);

    LoRa_Standby();

    s_state            = LORA_STATE_DISCONNECTED;
    g_txConnected      = 0;
    s_txSeq            = 0;
    s_lastDataTxTick   = 0;
    s_lastAnyTxTick    = 0;
    s_lastHelloTick    = 0;
    s_consecCycleFails = 0;

    UART_PrintLn("[LORA TX] Init done — long-range config active");
}

/* ── Main service routine — call once per cycle ─────────────────────── *
 *
 * Returns the outcome.  Caller (main.c) just calls this — the function
 * decides whether to send DATA, PING, or HELLO based on current state.
 *
 * Pass tank_level (0–100) and well_dry (0/1) every call.  They're
 * ignored when state != CONNECTED.
 * ──────────────────────────────────────────────────────────────────── */
LoRa_TxResult LoRa_Service(uint8_t tank_level, uint8_t well_dry)
{
    if (loraMode != LORA_MODE_TRANSMITTER)
        return LORA_TX_FAIL;

    uint32_t now = HAL_GetTick();

    /* ── State: DISCONNECTED ──────────────────────────────────────── *
     * We never send DATA here — only HELLO, paced by retry interval. */
    if (s_state == LORA_STATE_DISCONNECTED)
    {
        if ((now - s_lastHelloTick) < TX_HELLO_RETRY_INTERVAL_MS)
            return LORA_TX_SKIPPED;

        s_lastHelloTick = now;
        UART_PrintLn("[LORA TX] DISCONNECTED — sending HELLO");
        set_state(LORA_STATE_HANDSHAKING);

        if (do_handshake_once())
        {
            UART_PrintLn("[LORA TX] *** HANDSHAKE OK ***");
            /* Reset data timer to NOW so the first @TL waits a full
             * TX_DATA_INTERVAL_MS instead of firing immediately.
             * Without this, (now - 0) >= 10000 is already true and
             * data fires before the user even sees the CONNECTED log. */
            s_lastDataTxTick = HAL_GetTick();
            s_lastAnyTxTick  = HAL_GetTick();
            set_state(LORA_STATE_CONNECTED);
            s_consecCycleFails = 0;
            return LORA_TX_OK;
        }

        set_state(LORA_STATE_DISCONNECTED);
        return LORA_TX_RETRY;
    }

    /* ── State: HANDSHAKING (rare — one-shot transient) ──────────── */
    if (s_state == LORA_STATE_HANDSHAKING)
    {
        if (do_handshake_once())
        {
            s_lastDataTxTick = HAL_GetTick();   /* same fix as above */
            s_lastAnyTxTick  = HAL_GetTick();
            set_state(LORA_STATE_CONNECTED);
            s_consecCycleFails = 0;
            return LORA_TX_OK;
        }
        set_state(LORA_STATE_DISCONNECTED);
        return LORA_TX_RETRY;
    }

    /* ── State: CONNECTED ─────────────────────────────────────────── */
    /* Decide: data due?  ping due?  nothing? */
    bool data_due      = (now - s_lastDataTxTick) >= TX_DATA_INTERVAL_MS;
    bool keepalive_due = (now - s_lastAnyTxTick ) >= TX_KEEPALIVE_INTERVAL_MS;

    LoRa_TxResult result;

    if (data_due)
    {
        result = send_data_with_retries(tank_level, well_dry);
    }
    else if (keepalive_due)
    {
        UART_PrintLn("[LORA TX] Idle — sending PING keep-alive");
        result = send_ping() ? LORA_TX_OK : LORA_TX_RETRY;
    }
    else
    {
        return LORA_TX_SKIPPED;
    }

    /* ── Cycle-failure tracking → DISCONNECTED ─────────────────────── */
    if (result == LORA_TX_OK)
    {
        s_consecCycleFails = 0;
    }
    else
    {
        s_consecCycleFails++;
        char dbg[80];
        snprintf(dbg, sizeof(dbg),
                 "[LORA TX] No-ACK streak: %u/%u",
                 s_consecCycleFails, TX_NOACK_DISCONNECT_THRESH);
        UART_PrintLn(dbg);

        if (s_consecCycleFails >= TX_NOACK_DISCONNECT_THRESH)
        {
            UART_PrintLn("[LORA TX] !!! DISCONNECTED — will re-handshake !!!");
            set_state(LORA_STATE_DISCONNECTED);
            s_lastHelloTick = 0;   /* fire HELLO immediately next call */
        }
    }

    return result;
}

/* ── LoRa_Task() removed ────────────────────────────────────────────── *
 * The old LoRa_Task() compat shim has been removed.  It was the source
 * of confusion: it parsed the legacy txPacket (which always contained
 * an @TL: string built by ADC_ClassifyPacket) and gave the impression
 * that data packets were being transmitted when in fact the state
 * machine was sending HELLO.
 *
 * main.c now calls LoRa_Service(level, wd) directly.
 * The lora.h declaration for LoRa_Task() has been left as a thin
 * inline wrapper pointing to LoRa_Service(0,0) for any callers that
 * have not yet been updated.
 * ──────────────────────────────────────────────────────────────────── */
