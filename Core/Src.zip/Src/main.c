/* ====================================================================
 * main.c  —  TRANSMITTER (tank-level sensor node)
 *
 * ARCHITECTURE:
 *
 *   Main loop runs every 200 ms.  Timing for EVERYTHING is driven
 *   by the LoRa state machine and per-task timers — NOT by a big
 *   HAL_Delay(10000) that blocks everything.
 *
 *   Loop tick rate:   200 ms
 *   ADC read cadence: every 9 s (refresh data before the 10 s TX)
 *   HELLO retry:      every 3 s when DISCONNECTED  (in state machine)
 *   Data TX:          every 10 s when CONNECTED     (in state machine)
 *   PING keep-alive:  every 30 s if no data change  (in state machine)
 *
 *   This means:
 *     • When DISCONNECTED the TX tries HELLO on the very first loop
 *       tick that falls ≥ 3 s after the previous attempt — no waiting
 *       for a 10-second cycle to turn over.
 *     • When CONNECTED data TX fires on the state-machine cadence, not
 *       blocked by anything in main.c.
 *     • g_txConnected tracks the real LoRa connection state; it is
 *       only ever set inside set_state(LORA_STATE_CONNECTED).
 * ==================================================================== */

#include "main.h"
#include "adc.h"
#include "lora.h"
#include "device_id.h"
#include <stdio.h>
#include <string.h>

/* ── Cadences ────────────────────────────────────────────────────────── */
#define MAIN_LOOP_TICK_MS    200UL   /* polling rate for state machine   */
#define ADC_REFRESH_MS      9000UL   /* re-read sensors just before TX   */
#define BUTTON_DEBOUNCE_MS   200UL

/* ── Peripheral handles ─────────────────────────────────────────────── */
ADC_HandleTypeDef  hadc1;
I2C_HandleTypeDef  hi2c2;
RTC_HandleTypeDef  hrtc;
SPI_HandleTypeDef  hspi1;
TIM_HandleTypeDef  htim3;
UART_HandleTypeDef huart1;

ADC_Data adcData;

/* ── Globals used by lora.c (extern there) ──────────────────────────── */
extern uint8_t  loraMode;
extern uint32_t g_lora_tx_ok;
extern uint32_t g_lora_tx_retry;
extern uint32_t g_lora_tx_fail;
extern uint8_t  g_txConnected;
extern uint8_t  g_txDebugMode;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_I2C2_Init(void);
static void MX_TIM3_Init(void);

/* ── UART helpers ────────────────────────────────────────────────────── */
void UART_Print(const char *s)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)s, (uint16_t)strlen(s), 1000);
}

void UART_PrintLn(const char *s)
{
    UART_Print(s);
    UART_Print("\r\n");
}

/* ── Application entry point ────────────────────────────────────────── */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_ADC1_Init();
    MX_SPI1_Init();
    MX_USART1_UART_Init();
    MX_I2C2_Init();
    MX_TIM3_Init();

    ADC_Init(&hadc1);

    /* ── Startup banner ───────────────────────────────────────────── */
    UART_PrintLn("\r\n");
    UART_PrintLn("=========================================");
    UART_PrintLn("  HELONIX  -  TANK TRANSMITTER NODE");
    UART_PrintLn("  Firmware: LoRa Water Level TX v4.0");
    UART_PrintLn("  UART    : 115200 8N1");
    UART_PrintLn("  Loop    : 200 ms tick / 10 s data");
    UART_PrintLn("=========================================");

    /* Show silicon UID */
    {
        volatile uint32_t *uid = (volatile uint32_t *)0x1FFFF7E8UL;
        char buf[64];
        snprintf(buf, sizeof(buf), "[UID] %08lX %08lX %08lX",
                 (unsigned long)uid[2],
                 (unsigned long)uid[1],
                 (unsigned long)uid[0]);
        UART_PrintLn(buf);
    }

    /* ── LoRa init (also calls DeviceID_Init) ─────────────────────── */
    LoRa_Init();
    loraMode = LORA_MODE_TRANSMITTER;

    /* Display DID */
    {
        char myDID[9];
        DeviceID_GetHex(myDID);
        uint32_t didRaw = DeviceID_GetOwn();
        char buf[80];

        UART_PrintLn("-----------------------------------------");
        snprintf(buf, sizeof(buf), "[DID HEX] %s", myDID);      UART_PrintLn(buf);
        snprintf(buf, sizeof(buf), "[DID DEC] %lu", (unsigned long)didRaw); UART_PrintLn(buf);
        snprintf(buf, sizeof(buf), "[HELLO]   @HI:%s#", myDID); UART_PrintLn(buf);
        UART_PrintLn("-----------------------------------------");
        UART_PrintLn("[INIT] State: DISCONNECTED — will send HELLO every 3s");
        UART_PrintLn("[INFO] Press SWITCH1 to force immediate HELLO\r\n");
    }

    /* ── Initial ADC read so we have valid data on first TX ──────── */
    ADC_ReadAllChannels(&hadc1, &adcData);
    uint8_t currentLevel  = ADC_GetTankLevel();
    uint8_t currentWellDry = ADC_GetWellDry();

    /* ── Per-task timers ──────────────────────────────────────────── */
    uint32_t lastADCTick    = HAL_GetTick();
    uint32_t lastButtonTick = 0;
    uint32_t lastStatsTick  = 0;
    uint32_t loopCount      = 0;

    LoRa_TxResult lastResult = LORA_TX_SKIPPED;
    uint8_t       prevConnected = 0;

    /* ── Main loop ────────────────────────────────────────────────── *
     * Runs at MAIN_LOOP_TICK_MS.  All real cadence is in state machine.
     * ──────────────────────────────────────────────────────────────── */
    while (1)
    {
        uint32_t loopStart = HAL_GetTick();
        loopCount++;

        /* ── 1. Button: force immediate HELLO ──────────────────── */
        if ((loopStart - lastButtonTick) >= BUTTON_DEBOUNCE_MS)
        {
            lastButtonTick = loopStart;
            if (HAL_GPIO_ReadPin(GPIOB, SWITCH1_Pin) == GPIO_PIN_RESET)
            {
                UART_PrintLn("\r\n[BTN] Manual HELLO requested");
                LoRa_ManualHello();
            }
        }

        /* ── 2. ADC refresh (every 9 s, just before data TX) ───── *
         * By refreshing slightly before the 10-second TX cadence,
         * the values sent are always fresh.                         */
        if ((loopStart - lastADCTick) >= ADC_REFRESH_MS)
        {
            lastADCTick = loopStart;
            ADC_ReadAllChannels(&hadc1, &adcData);
            currentLevel   = ADC_GetTankLevel();
            currentWellDry = ADC_GetWellDry();

            char buf[80];
            snprintf(buf, sizeof(buf),
                     "[ADC] Level:%u%%  WellDry:%u  State:%s",
                     currentLevel, currentWellDry, LoRa_GetStateString());
            UART_PrintLn(buf);
        }

        /* ── 3. LoRa service — THE only place TX happens ───────── *
         *
         * Pass current ADC values.  The function decides internally
         * whether to:
         *   DISCONNECTED → send @HI (every 3 s)
         *   HANDSHAKING  → send @HI (immediate retry)
         *   CONNECTED    → send @TL (every 10 s) or @PI (every 30 s)
         *
         * If not enough time has elapsed it returns LORA_TX_SKIPPED
         * and does nothing — no radio activity.
         * ──────────────────────────────────────────────────────── */
        LoRa_TxResult result = LoRa_Service(currentLevel, currentWellDry);

        /* ── 4. Log only meaningful events (not every 200 ms) ──── */
        bool connChanged = (g_txConnected != prevConnected);

        if (connChanged)
        {
            prevConnected = g_txConnected;
            if (g_txConnected)
                UART_PrintLn("\r\n[EVENT] *** CONNECTED — data will flow every 10 s ***");
            else
                UART_PrintLn("\r\n[EVENT] *** DISCONNECTED — sending HELLO every 3 s ***");
        }

        /* Log every non-SKIPPED result */
        if (result != LORA_TX_SKIPPED && result != lastResult)
        {
            lastResult = result;
        }

        if (result == LORA_TX_OK)
        {
            char buf[100];
            snprintf(buf, sizeof(buf),
                     "[TX-OK] State:%s  Level:%u%%  WD:%u  OK:%lu  Fail:%lu",
                     LoRa_GetStateString(), currentLevel, currentWellDry,
                     (unsigned long)g_lora_tx_ok, (unsigned long)g_lora_tx_fail);
            UART_PrintLn(buf);
        }
        else if (result == LORA_TX_RETRY || result == LORA_TX_FAIL)
        {
            char buf[80];
            snprintf(buf, sizeof(buf),
                     "[TX-FAIL] State:%s  NoACK — streak logged",
                     LoRa_GetStateString());
            UART_PrintLn(buf);
        }

        /* ── 5. Periodic stats every 60 s ─────────────────────── */
        if ((loopStart - lastStatsTick) >= 60000UL)
        {
            lastStatsTick = loopStart;
            uint32_t total = g_lora_tx_ok + g_lora_tx_retry + g_lora_tx_fail;
            uint32_t rate  = (total > 0) ? ((g_lora_tx_ok * 100u) / total) : 0u;
            char buf[120];

            UART_PrintLn("-------- TX Statistics --------");
            snprintf(buf, sizeof(buf), "  State  : %s", LoRa_GetStateString()); UART_PrintLn(buf);
            snprintf(buf, sizeof(buf), "  OK     : %lu", (unsigned long)g_lora_tx_ok);    UART_PrintLn(buf);
            snprintf(buf, sizeof(buf), "  Retry  : %lu", (unsigned long)g_lora_tx_retry); UART_PrintLn(buf);
            snprintf(buf, sizeof(buf), "  Fail   : %lu", (unsigned long)g_lora_tx_fail);  UART_PrintLn(buf);
            snprintf(buf, sizeof(buf), "  ACK%%   : %lu%%", (unsigned long)rate);          UART_PrintLn(buf);
            UART_PrintLn("-------------------------------");
        }

        /* ── 6. Pace the loop ───────────────────────────────────── */
        uint32_t elapsed = HAL_GetTick() - loopStart;
        if (elapsed < MAIN_LOOP_TICK_MS)
            HAL_Delay(MAIN_LOOP_TICK_MS - elapsed);
    }
}

/* ====================================================================
 * Peripheral init (unchanged from project — do not modify)
 * ==================================================================== */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef       RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef       RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInit     = {0};

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_LSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.LSIState            = RCC_LSI_ON;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI_DIV2;
    RCC_OscInitStruct.PLL.PLLMUL          = RCC_PLL_MUL16;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                                       RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();

    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC | RCC_PERIPHCLK_ADC;
    PeriphClkInit.RTCClockSelection    = RCC_RTCCLKSOURCE_LSI;
    PeriphClkInit.AdcClockSelection    = RCC_ADCPCLK2_DIV6;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) Error_Handler();
}

static void MX_ADC1_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};
    hadc1.Instance                   = ADC1;
    hadc1.Init.ScanConvMode          = ADC_SCAN_DISABLE;
    hadc1.Init.ContinuousConvMode    = DISABLE;
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConv      = ADC_SOFTWARE_START;
    hadc1.Init.DataAlign             = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion       = 8;
    if (HAL_ADC_Init(&hadc1) != HAL_OK) Error_Handler();

    uint32_t chList[] = {
        ADC_CHANNEL_0, ADC_CHANNEL_1, ADC_CHANNEL_2, ADC_CHANNEL_3,
        ADC_CHANNEL_4, ADC_CHANNEL_5, ADC_CHANNEL_7, ADC_CHANNEL_6
    };
    for (uint8_t r = 0; r < 8; r++)
    {
        sConfig.Channel      = chList[r];
        sConfig.Rank         = r + 1;
        sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
        if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK) Error_Handler();
    }
}

static void MX_I2C2_Init(void)
{
    hi2c2.Instance             = I2C2;
    hi2c2.Init.ClockSpeed      = 100000;
    hi2c2.Init.DutyCycle       = I2C_DUTYCYCLE_2;
    hi2c2.Init.OwnAddress1     = 0;
    hi2c2.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
    hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c2.Init.OwnAddress2     = 0;
    hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c2.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c2) != HAL_OK) Error_Handler();
}

static void MX_SPI1_Init(void)
{
    hspi1.Instance               = SPI1;
    hspi1.Init.Mode              = SPI_MODE_MASTER;
    hspi1.Init.Direction         = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize          = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity       = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase          = SPI_PHASE_1EDGE;
    hspi1.Init.NSS               = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
    hspi1.Init.FirstBit          = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode            = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
    hspi1.Init.CRCPolynomial     = 10;
    if (HAL_SPI_Init(&hspi1) != HAL_OK) Error_Handler();
}

static void MX_TIM3_Init(void)
{
    TIM_ClockConfigTypeDef  sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig      = {0};
    htim3.Instance               = TIM3;
    htim3.Init.Prescaler         = 0;
    htim3.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim3.Init.Period            = 0xFFFF;
    htim3.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim3) != HAL_OK) Error_Handler();
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK) Error_Handler();
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode     = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) Error_Handler();
}

static void MX_USART1_UART_Init(void)
{
    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 115200;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart1) != HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOB,
        Relay1_Pin | Relay2_Pin | Relay3_Pin | LORA_STATUS_Pin | LED4_Pin | LED5_Pin,
        GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA,
        LED1_Pin | LED2_Pin | LED3_Pin | LORA_SELECT_Pin,
        GPIO_PIN_RESET);

    GPIO_InitStruct.Pin   = Relay1_Pin | Relay2_Pin | Relay3_Pin |
                            LORA_STATUS_Pin | LED4_Pin | LED5_Pin;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_InitStruct.Pin  = SWITCH1_Pin | SWITCH2_Pin | SWITCH3_Pin | SWITCH4_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_InitStruct.Pin   = LED1_Pin | LED2_Pin | LED3_Pin | LORA_SELECT_Pin;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin  = RF_DATA_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(RF_DATA_GPIO_Port, &GPIO_InitStruct);
}

void Error_Handler(void)
{
    UART_PrintLn("[ERROR] Error_Handler — system halted!");
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    char msg[64];
    snprintf(msg, sizeof(msg), "[ASSERT] %s line %lu", (char *)file, line);
    UART_PrintLn(msg);
}
#endif
